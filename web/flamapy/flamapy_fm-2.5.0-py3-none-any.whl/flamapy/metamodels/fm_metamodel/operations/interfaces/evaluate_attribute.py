from abc import abstractmethod
from typing import Any

from flamapy.core.operations import Operation
from flamapy.metamodels.configuration_metamodel.models import Configuration


class EvaluateAttribute(Operation):
    """Computes the value of a given attribute in a configuration by aggregating 
    the attribute values of all selected features in the feature model.
    """

    @abstractmethod
    def __init__(self) -> None:
        pass

    @abstractmethod
    def get_attribute_value(self) -> Any:
        pass

    @abstractmethod
    def set_configuration(self, configuration: Configuration) -> None:
        pass

    @abstractmethod
    def set_attribute(self, attribute_name: str) -> None:
        pass
